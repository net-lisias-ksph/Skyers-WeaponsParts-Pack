Install instructions:
Unzip contents and place them in GameData folder.

